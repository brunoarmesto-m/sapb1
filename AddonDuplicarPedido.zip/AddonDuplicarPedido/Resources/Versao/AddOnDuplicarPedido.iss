[Setup]
AppName=AddOnDuplicarPedido
AppVerName=AddOnDuplicarPedido
AppPublisher=B1Sys
AppPublisherURL=http://www.b1sys.com.br
DefaultDirName={code:GetDefaultAddOnDir}
DisableDirPage=yes
DisableProgramGroupPage=yes
OutputDir=D:\DESENV\B1SYS\Reis\AddonDuplicarPedido\AddonDuplicarPedido\Resources\Versao
OutputBaseFilename=AddOnDuplicarPedido 1.0.1.1
Compression=lzma
SolidCompression=yes
PrivilegesRequired=admin

[Files]

Source: "D:\DESENV\B1SYS\Reis\AddonDuplicarPedido\AddonDuplicarPedido\bin\Release\AddonDuplicarPedido.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "C:\DEV\Aprov\Aprovacao\Aprovacao\obj\Release\Interop.SAPbobsCOM.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "C:\DEV\Aprov\Aprovacao\Aprovacao\obj\Release\Interop.SAPbouiCOM.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "D:\DESENV\B1SYS\Reis\AddonDuplicarPedido\AddonDuplicarPedido\bin\Release\B1Syswork.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "D:\DESENV\B1SYS\Reis\AddonDuplicarPedido\AddonDuplicarPedido\bin\Release\Resources\XML\Menu.xml"; DestDir: "{app}\Resources\Xml"; Flags: ignoreversion
Source: "D:\DESENV\B1SYS\Reis\AddonDuplicarPedido\AddonDuplicarPedido\bin\Release\Forms\*"; DestDir: "{app}\Resources\Forms\"; Flags: ignoreversion

[Dirs]
Name: "{app}\Temp";

[Code]

const
  ADDON_ID   = 'AddOnDuplicarPedido';
  PARTNER_ID = 'B1Sys';

// Fun��es externas (AddOnInstallAPI.dll)
function SetAddOnFolder(path: string): integer; external 'SetAddOnFolder@AddOnInstallAPI.dll stdcall setuponly';
function EndInstallEx(path: string; succeed: boolean): integer; external 'EndInstallEx@AddOnInstallAPI.dll stdcall setuponly';
function EndUninstall(path: string; succeed: boolean): integer; external 'EndUninstall@AddOnInstallAPI.dll stdcall uninstallonly';

function GetDLLPath(IsUninstalling: boolean): string;
var ValueName: string;
begin

  if IsUninstalling then begin
    RegQueryStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\' + PARTNER_ID + '\' + ADDON_ID, 'DLLInstallDir', ValueName);
    Result := ValueName;
  end
  else
    Result := Copy(ParamStr(6), Pos('|', ParamStr(6))+1, Length(ParamStr(6))-Pos('|', ParamStr(6)));

end;

function GetDefaultAddOnDir(param: String): string;
begin
  Result := Copy(ParamStr(6), 1, Pos('|', ParamStr(6))-1);
end;

// Grava no Registro a chave que identifica onde o add-on foi instalado
procedure RegisterAddOnInfo();
begin
  RegWriteStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\' + PARTNER_ID + '\' + ADDON_ID, 'InstallDir', ExpandConstant('{app}'));
  RegWriteStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\' + PARTNER_ID + '\' + ADDON_ID, 'DLLInstallDir', GetDLLPath(false));
end;

procedure UnregisterAddOnInfo();
begin
  RegDeleteValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\' + PARTNER_ID + '\' + ADDON_ID, 'InstallDir');
  RegDeleteValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\' + PARTNER_ID + '\' + ADDON_ID, 'DLLInstallDir');
  RegDeleteKeyIfEmpty(HKEY_LOCAL_MACHINE, 'SOFTWARE\' + PARTNER_ID + '\' + ADDON_ID);
end;


function GetAddOnInstalledPath(): string;
var ValueName: string;
begin
  RegQueryStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\' + PARTNER_ID + '\' + ADDON_ID, 'InstallDir', ValueName);
  Result := ValueName;
end;



//*******************************************************************************************************
//  InitializeSetup (fun��o interna do Inno)
//  Executada sempre que a instala��o/desinstala��o inicia
//*******************************************************************************************************
function InitializeSetup(): boolean;
var ResultCode: integer;
begin

  // Est� desinstalando...
  if ParamStr(6) = '/u' then begin
    SetCurrentDir(GetDLLPath(true));
    Exec(GetAddOnInstalledPath + '\unins000.exe', '', '', SW_SHOW, ewWaitUntilTerminated, ResultCode)
    Result := false;
  end

  // Est� na instala��o...
  else begin

    // A instala��o tentou ser executada fora do SBOne?
    if Pos('|', ParamStr(6)) = 0 then begin
      MsgBox('This installer must be run from SAP Business One.', mbInformation, MB_OK);
      Result := false;
    end

    // Ok, instalando de dentro do SBOne...
    else begin

      // Muda para o diret�rio onde o SBOne indicou estar a DLL AddOnInstallAPI.dll, para n�o dar "pau"
      // nas fun��es que utilizam ela   sdsadd
      SetCurrentDir(GetDLLPath(false));

      Result := true;

    end;

  end;

end;

//*******************************************************************************************************
//  CurStepChanged (fun��o interna do Inno)
//
//*******************************************************************************************************
procedure CurStepChanged(CurStep: TSetupStep);
begin

  // Ao terminar a instala��o com sucesso informa ao SB1 o diret�rio
  // de instala��o e d� o sinal de que a instala��o terminou
  if CurStep = ssPostInstall then begin
    RegisterAddOnInfo(); // grava a chave de instala��o do add-on no Registro
    SetAddOnFolder(ExpandConstant('{app}'));
    EndInstallEx(ExpandConstant('{app}'), true);
    UnloadDLL('AddOnInstallAPI.dll');
  end;

end;

procedure DeinitializeSetup();
begin
    EndInstallEx('', false);
    UnloadDLL('AddOnInstallAPI.dll');  // instala��o cancelada
end;

//*******************************************************************************************************
//  CurUninstallStepChanged (fun��o interna do Inno)
//
//*******************************************************************************************************
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin

  // Ao terminar a desinstala��o com sucesso avisa ao SB1
  if CurUninstallStep = usPostUninstall then begin
    UnregisterAddOnInfo(); // Remove do Registro a pasta de instala��o do add-on
    EndUninstall(ExpandConstant('{app}'), true);
    UnloadDLL('AddOnInstallAPI.dll');
  end;

end;

procedure DeinitializeUninstall();
begin
  EndUninstall('', false);
  UnloadDLL('AddOnInstallAPI.dll');
end;
