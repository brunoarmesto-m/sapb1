﻿using AddonDuplicarPedido.Duplicar.Banco;
using AddonDuplicarPedido.Duplicar.Obj;
using B1Syswork;
using SAPbouiCOM;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace AddonDuplicarPedido.Duplicar
{
    public class Form : FormTemplate
    {
        private StreamWriter writer;
        public Form()
        {
            try
            {
                this.oPacote = Addon.Application.CreateObject(BoCreatableObjectType.cot_FormCreationParams);
                this.oPacote.XmlData = System.Xml.Linq.XDocument.Load(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + String.Format("\\Resources\\Forms\\{0}.srf", this.GetType().Name)).ToString();
                this.Form = Addon.Application.Forms.AddEx(this.oPacote);

                this.oRecordSet = Addon.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

                #region Posicionamento

                this.Top = ((System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height - this.ClientHeight) / 2) - 75;
                this.Left = (System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width - this.ClientWidth) / 2;

                #endregion

                this.VisibleEx = true;
            }
            catch (Exception ex)
            {
                Addon.Application.StatusBar.SetText("Erro: " + ex.Message, BoMessageTime.bmt_Medium, BoStatusBarMessageType.smt_Error);
                this.Close();
            }

        }

        #region METODOS


        public void Duplicar(List<Pedido> pedidos)
        {

            if (pedidos.Any())
            {
                writer = new StreamWriter(this.DataSources.UserDataSources.Item("udlog").ValueEx + "\\Log_" + DateTime.Now.ToString("yyyyMMddHHMMss ") + ".txt");
                writer.WriteLine(DateTime.Now.ToString("dd/MM/yyyy HH:MM") + " -> Inicio duplicação pedido de vendas");

                foreach (var pedido in pedidos)
                {
                    SAPbobsCOM.Documents documents = Addon.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oOrders);

                    documents.DocDate = pedido.DocDate;
                    documents.DocDueDate = DateTime.Now;
                    documents.CardCode = pedido.CardCode;
                    documents.Comments = pedido.Comments + "    Pedido gerado a partir do PV -> " + pedido.PedidoOrigem;
                    if (!string.IsNullOrEmpty(pedido.Indicator))
                        documents.Indicator = pedido.Indicator;

                    if (!string.IsNullOrEmpty(pedido.Project))
                        documents.Project = pedido.Project;
                    //documents.BPL_IDAssignedToInvoice = pedido.BPLId;
                    //documents.SequenceCode = pedido.SeqCode;

#if !DEBUG
                    if (!string.IsNullOrEmpty(pedido.U_LG_Reembolso))
                        documents.UserFields.Fields.Item("U_LG_Reembolso").Value = pedido.U_LG_Reembolso;
                    if (!string.IsNullOrEmpty(pedido.U_LG_Gerado))
                        documents.UserFields.Fields.Item("U_LG_Gerado").Value = pedido.U_LG_Gerado;


                    if (!string.IsNullOrEmpty(pedido.U_LG_Imagem))
                        documents.UserFields.Fields.Item("U_LG_Imagem").Value = pedido.U_LG_Imagem;

                    if (!string.IsNullOrEmpty(pedido.U_Reis_Obs_Finan))
                        documents.UserFields.Fields.Item("U_Reis_Obs_Finan").Value = pedido.U_Reis_Obs_Finan;


                    if (!string.IsNullOrEmpty(pedido.U_LG_NmroLote))
                        documents.UserFields.Fields.Item("U_LG_NmroLote").Value = pedido.U_LG_NmroLote;


                    if (!string.IsNullOrEmpty(pedido.U_LG_DocNumOP))
                        documents.UserFields.Fields.Item("U_LG_DocNumOP").Value = pedido.U_LG_DocNumOP;


                    if (!string.IsNullOrEmpty(pedido.U_LG_Imagem1))
                        documents.UserFields.Fields.Item("U_LG_Imagem1").Value = pedido.U_LG_Imagem1;


                    if (!string.IsNullOrEmpty(pedido.U_LG_Imagem2))
                        documents.UserFields.Fields.Item("U_LG_Imagem2").Value = pedido.U_LG_Imagem2;

                    if (!string.IsNullOrEmpty(pedido.U_ObservacaoStatus))
                        documents.UserFields.Fields.Item("U_ObservacaoStatus").Value = pedido.U_ObservacaoStatus;


                    if (!string.IsNullOrEmpty(pedido.U_Reis_Penalizacao))
                        documents.UserFields.Fields.Item("U_Reis_Penalizacao").Value = pedido.U_Reis_Penalizacao;


                    if (!string.IsNullOrEmpty(pedido.U_U_Reis_StatusNovo))
                        documents.UserFields.Fields.Item("U_U_Reis_StatusNovo").Value = pedido.U_U_Reis_StatusNovo;


                    if (!string.IsNullOrEmpty(pedido.U_NossoNumero))
                        documents.UserFields.Fields.Item("U_NossoNumero").Value = pedido.U_NossoNumero;

                    if (!string.IsNullOrEmpty(pedido.U_Antecipado))
                        documents.UserFields.Fields.Item("U_Antecipado").Value = pedido.U_Antecipado;
#endif
                    bool add = false;
                    foreach (var item in pedido.Itens)
                    {
                        if (add)
                            documents.Lines.Add();

                        documents.Lines.ItemCode = item.itemcode;
                        documents.Lines.Quantity = Convert.ToDouble(item.quantity);
                        documents.Lines.Price = Convert.ToDouble(item.price);
                        documents.Lines.DiscountPercent = Convert.ToDouble(item.discprcnt);
                        documents.Lines.LineTotal = Convert.ToDouble(item.linetotal);
                        documents.Lines.WarehouseCode = item.whscode;
                        documents.Lines.VendorNum = item.slpcode;
                        documents.Lines.ProjectCode = item.project;
                        documents.Lines.TaxCode = item.taxcode;
                        documents.Lines.Usage = item.usage;
                        documents.Lines.CostingCode = item.ocrcode;
                        documents.Lines.CostingCode2 = item.ocrcode2;
                        documents.Lines.CostingCode3 = item.ocrcode3;
                        documents.Lines.CostingCode4 = item.ocrcode4;
                        documents.Lines.CostingCode5 = item.ocrcode5;
#if !DEBUG
                        if (!string.IsNullOrEmpty(item.u_cstipi))
                            documents.Lines.UserFields.Fields.Item("U_CSTIPI").Value = item.u_cstipi;
                        if (!string.IsNullOrEmpty(item.u_cstpis))
                            documents.Lines.UserFields.Fields.Item("U_CSTPIS").Value = item.u_cstpis;
                        if (!string.IsNullOrEmpty(item.u_cstcofins))
                            documents.Lines.UserFields.Fields.Item("U_CSTCOFINS").Value = item.u_cstcofins;
                        if (!string.IsNullOrEmpty(item.u_lg_chavedesp))
                            documents.Lines.UserFields.Fields.Item("U_LG_ChaveDesp").Value = item.u_lg_chavedesp;
                        if (!string.IsNullOrEmpty(item.u_lg_nmrolote))
                            documents.Lines.UserFields.Fields.Item("U_LG_NmroLote").Value = item.u_lg_nmrolote;
                        if (!string.IsNullOrEmpty(item.u_lg_nmroprotocolo))
                            documents.Lines.UserFields.Fields.Item("U_LG_NmroProtocolo").Value = item.u_lg_nmroprotocolo;
                        if (!string.IsNullOrEmpty(item.u_lg_chavetedesco))
                            documents.Lines.UserFields.Fields.Item("U_LG_ChaveTedesco").Value = item.u_lg_chavetedesco;
                        if (!string.IsNullOrEmpty(item.u_tipo_doc))
                            documents.Lines.UserFields.Fields.Item("U_TIPO_DOC").Value = item.u_tipo_doc;
                        if (!string.IsNullOrEmpty(item.u_cep))
                            documents.Lines.UserFields.Fields.Item("U_CEP").Value = item.u_cep;
                        if (!string.IsNullOrEmpty(item.u_envi_para))
                            documents.Lines.UserFields.Fields.Item("U_ENVI_PARA").Value = item.u_envi_para;
                        if (!string.IsNullOrEmpty(item.u_nome_solic))
                            documents.Lines.UserFields.Fields.Item("U_NOME_SOLIC").Value = item.u_nome_solic;
                        if (!string.IsNullOrEmpty(item.u_cidade))
                            documents.Lines.UserFields.Fields.Item("U_CIDADE").Value = item.u_cidade;
                        if (!string.IsNullOrEmpty(item.u_possui_ar))
                            documents.Lines.UserFields.Fields.Item("U_POSSUI_AR").Value = item.u_possui_ar;
                        if (!string.IsNullOrEmpty(item.u_meio_envio))
                            documents.Lines.UserFields.Fields.Item("U_MEIO_ENVIO").Value = item.u_meio_envio;
                        if (!string.IsNullOrEmpty(item.u_obs))
                            documents.Lines.UserFields.Fields.Item("U_OBS").Value = item.u_obs;
                        if (!string.IsNullOrEmpty(item.u_reis_datafiltro))
                            documents.Lines.UserFields.Fields.Item("U_Reis_DataFiltro").Value = item.u_reis_datafiltro;
                        if (!string.IsNullOrEmpty(item.u_u_reis_matriculadm))
                            documents.Lines.UserFields.Fields.Item("U_U_Reis_MatriculaDM").Value = item.u_u_reis_matriculadm;
                        if (!string.IsNullOrEmpty(item.u_reis_custodesp))
                            documents.Lines.UserFields.Fields.Item("U_REIS_CustoDesp").Value = item.u_reis_custodesp;
                        if (!string.IsNullOrEmpty(item.u_reis_fixovariavel))
                            documents.Lines.UserFields.Fields.Item("U_REIS_FixoVariavel").Value = item.u_reis_fixovariavel;
                        if (!string.IsNullOrEmpty(item.u_reis_diretoindireto))
                            documents.Lines.UserFields.Fields.Item("U_REIS_DiretoIndireto").Value = item.u_reis_diretoindireto;
                        if (!string.IsNullOrEmpty(item.u_reis_frete))
                            documents.Lines.UserFields.Fields.Item("U_REIS_Frete").Value = item.u_reis_frete;
                        if (!string.IsNullOrEmpty(item.u_alt_project))
                            documents.Lines.UserFields.Fields.Item("U_alt_project").Value = item.u_alt_project;
                        if (!string.IsNullOrEmpty(item.u_alt_ocrcode))
                            documents.Lines.UserFields.Fields.Item("U_alt_ocrcode").Value = item.u_alt_ocrcode;

                        if (!string.IsNullOrEmpty(item.u_alt_ocrcode2))
                            documents.Lines.UserFields.Fields.Item("U_alt_ocrcode2").Value = item.u_alt_ocrcode2;
                        if (!string.IsNullOrEmpty(item.u_alt_ocrcode3))
                            documents.Lines.UserFields.Fields.Item("U_alt_ocrcode3").Value = item.u_alt_ocrcode3;
                        if (!string.IsNullOrEmpty(item.u_alt_ocrcode4))
                            documents.Lines.UserFields.Fields.Item("U_alt_ocrcode4").Value = item.u_alt_ocrcode4;
#endif
                        add = true;
                    }

                    if (documents.Add() != 0)
                        this.EventoLog(new Log()
                        {
                            TipoMsg = 1,
                            Cliente = pedido.CardCode,
                            Mensagem = AddOn.Company.GetLastErrorDescription()
                        });
                    else
                        this.EventoLog(new Log()
                        {
                            TipoMsg = 0,
                            Cliente = pedido.CardCode,
                            Documento = AddOn.Company.GetNewObjectKey(),
                            Mensagem = AddOn.Company.GetLastErrorDescription()
                        });
                    this.FecharPedido(pedido.PedidoOrigem);
                }

                writer.WriteLine(DateTime.Now.ToString("dd/MM/yyyy HH:MM") + " -> Fim duplicação pedido de vendas");

                writer.Close();
            }
        }

        public void FecharPedido(string pedido)
        {
            
            SAPbobsCOM.Documents documents = Addon.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oOrders);
            if (documents.GetByKey(Convert.ToInt32(pedido)))
                documents.Close();

        }
        public void Processar()
        {
            List<Pedido> pedidos = new List<Pedido>();
            Pedido pedido;
            string[] lines = System.IO.File.ReadAllLines(this.DataSources.UserDataSources.Item("udEx").ValueEx);
            foreach (var line in lines)
            {
                var info = line.Split(';');
                this.oRecordSet.DoQuery(string.Format(Query.PedidoVenda(), info[1]));
                this.oRecordSet.MoveFirst();
                if (!this.oRecordSet.EoF)
                {
                    pedido = new Pedido();
                    pedido.CardCode = Convert.ToString(info[0]).Trim();
                    pedido.DocDate = DateTime.Now;
                    pedido.DocDueDate = DateTime.Now;
                    pedido.Comments = Convert.ToString(this.oRecordSet.Fields.Item("COMMENTS").Value);
                    pedido.Indicator = Convert.ToString(this.oRecordSet.Fields.Item("INDICATOR").Value);
                    pedido.Project = Convert.ToString(this.oRecordSet.Fields.Item("Project").Value);
                    pedido.BPLId = Convert.ToInt16(this.oRecordSet.Fields.Item("BPLID").Value);
                    pedido.SeqCode = Convert.ToInt16(this.oRecordSet.Fields.Item("SEQCODE").Value);
                    pedido.PedidoOrigem = Convert.ToString(info[1]);
#if !DEBUG
                    pedido.U_LG_Reembolso = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_REEMBOLSO").Value);
                    pedido.U_LG_Gerado = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_GERADO").Value);
                    pedido.U_LG_Imagem = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_IMAGEM").Value);
                    pedido.U_Reis_Obs_Finan = Convert.ToString(this.oRecordSet.Fields.Item("U_REIS_OBS_FINAN").Value);
                    pedido.U_LG_NmroLote = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_NMROLOTE").Value);
                    pedido.U_LG_DocNumOP = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_DOCNUMOP").Value);
                    pedido.U_LG_Imagem1 = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_IMAGEM1").Value);
                    pedido.U_LG_Imagem2 = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_IMAGEM2").Value);
                    pedido.U_ObservacaoStatus = Convert.ToString(this.oRecordSet.Fields.Item("U_OBSERVACAOSTATUS").Value);
                    pedido.U_Reis_Penalizacao = Convert.ToString(this.oRecordSet.Fields.Item("U_REIS_PENALIZACAO").Value);
                    pedido.U_U_Reis_StatusNovo = Convert.ToString(this.oRecordSet.Fields.Item("U_U_REIS_STATUSNOVO").Value);
                    pedido.U_NossoNumero = Convert.ToString(this.oRecordSet.Fields.Item("U_NOSSONUMERO").Value);
                    pedido.U_Antecipado = Convert.ToString(this.oRecordSet.Fields.Item("U_ANTECIPADO").Value);
#endif


                    for (int i = 0; i < this.oRecordSet.RecordCount; i++)
                    {
                        pedido.Itens.Add(new Obj.Item()
                        {
                            itemcode = Convert.ToString(this.oRecordSet.Fields.Item("ITEMCODE").Value),
                            quantity = Convert.ToString(this.oRecordSet.Fields.Item("QUANTITY").Value),
                            price = Convert.ToString(this.oRecordSet.Fields.Item("PRICE").Value),
                            discprcnt = Convert.ToString(this.oRecordSet.Fields.Item("DISCPRCNT").Value),
                            linetotal = Convert.ToString(this.oRecordSet.Fields.Item("LINETOTAL").Value),
                            whscode = Convert.ToString(this.oRecordSet.Fields.Item("WHSCODE").Value),
                            slpcode = Convert.ToString(this.oRecordSet.Fields.Item("SLPCODE").Value),
                            commission = Convert.ToString(this.oRecordSet.Fields.Item("COMMISSION").Value),
                            acctcode = Convert.ToString(this.oRecordSet.Fields.Item("ACCTCODE").Value),
                            ocrcode = Convert.ToString(this.oRecordSet.Fields.Item("OCRCODE").Value),
                            project = Convert.ToString(this.oRecordSet.Fields.Item("PROJECT").Value),
                            taxcode = Convert.ToString(this.oRecordSet.Fields.Item("TAXCODE").Value),
                            usage = Convert.ToString(this.oRecordSet.Fields.Item("USAGE").Value),
                            ocrcode2 = Convert.ToString(this.oRecordSet.Fields.Item("OCRCODE2").Value),
                            ocrcode3 = Convert.ToString(this.oRecordSet.Fields.Item("OCRCODE3").Value),
                            ocrcode4 = Convert.ToString(this.oRecordSet.Fields.Item("OCRCODE4").Value),
                            ocrcode5 = Convert.ToString(this.oRecordSet.Fields.Item("OCRCODE5").Value),
#if !DEBUG
                            u_cstpis = Convert.ToString(this.oRecordSet.Fields.Item("U_CSTPIS").Value),
                            u_cstcofins = Convert.ToString(this.oRecordSet.Fields.Item("U_CSTCOFINS").Value),
                            u_lg_chavedesp = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_CHAVEDESP").Value),
                            u_lg_nmrolote = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_NMROLOTE").Value),
                            u_lg_nmroprotocolo = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_NMROPROTOCOLO").Value),
                            u_lg_chavetedesco = Convert.ToString(this.oRecordSet.Fields.Item("U_LG_CHAVETEDESCO").Value),
                            u_tipo_doc = Convert.ToString(this.oRecordSet.Fields.Item("U_TIPO_DOC").Value),
                            u_cep = Convert.ToString(this.oRecordSet.Fields.Item("U_CEP").Value),
                            u_envi_para = Convert.ToString(this.oRecordSet.Fields.Item("U_ENVI_PARA").Value),
                            u_nome_solic = Convert.ToString(this.oRecordSet.Fields.Item("U_NOME_SOLIC").Value),
                            u_cidade = Convert.ToString(this.oRecordSet.Fields.Item("U_CIDADE").Value),
                            u_possui_ar = Convert.ToString(this.oRecordSet.Fields.Item("U_POSSUI_AR").Value),
                            u_meio_envio = Convert.ToString(this.oRecordSet.Fields.Item("U_MEIO_ENVIO").Value),
                            u_obs = Convert.ToString(this.oRecordSet.Fields.Item("U_OBS").Value),
                            u_reis_datafiltro = Convert.ToString(this.oRecordSet.Fields.Item("U_REIS_DATAFILTRO").Value),
                            u_u_reis_matriculadm = Convert.ToString(this.oRecordSet.Fields.Item("U_U_REIS_MATRICULADM").Value),
                            u_reis_custodesp = Convert.ToString(this.oRecordSet.Fields.Item("U_U_REIS_MATRICULADM").Value),
                            u_reis_fixovariavel = Convert.ToString(this.oRecordSet.Fields.Item("U_REIS_FIXOVARIAVEL").Value),
                            u_reis_diretoindireto = Convert.ToString(this.oRecordSet.Fields.Item("U_REIS_DIRETOINDIRETO").Value),
                            u_reis_frete = Convert.ToString(this.oRecordSet.Fields.Item("U_REIS_FRETE").Value),
                            u_alt_project = Convert.ToString(this.oRecordSet.Fields.Item("U_ALT_PROJECT").Value),
                            u_alt_ocrcode = Convert.ToString(this.oRecordSet.Fields.Item("U_ALT_OCRCODE").Value),
                            u_alt_ocrcode2 = Convert.ToString(this.oRecordSet.Fields.Item("U_ALT_OCRCODE2").Value),
                            u_alt_ocrcode3 = Convert.ToString(this.oRecordSet.Fields.Item("U_ALT_OCRCODE3").Value),
                            u_alt_ocrcode4 = Convert.ToString(this.oRecordSet.Fields.Item("U_ALT_OCRCODE4").Value),
                            u_alt_ocrcode5 = Convert.ToString(this.oRecordSet.Fields.Item("U_ALT_OCRCODE5").Value)
#endif

                        });
                        this.oRecordSet.MoveNext();
                    }


                    pedidos.Add(pedido);
                }

            }
            this.Duplicar(pedidos);

        }
        public void EventoLog(Log log)
        {
            if (log.TipoMsg == 0)
                writer.WriteLine("SUCESSO -> Pedido de venda adicionado com sucesso(Cliente: " + log.Cliente + ", Pedido: " + log.Documento + ")");
            else
                writer.WriteLine("ERRO -> Problema ao adicionar pedido de venda (Cliente: " + log.Cliente + ", MSG: " + log.Mensagem + ")");
        }
        #endregion

        #region EVENTOS USADOS
        public override void SBO_ItemPressed(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {
            try
            {
                if (pVal.BeforeAction == false && pVal.ItemUID == "btDup")
                {
                    this.Freeze(true);
                    Addon.Application.StatusBar.SetText("Aguarde..", BoMessageTime.bmt_Medium, BoStatusBarMessageType.smt_Warning);
                    this.Processar();
                    Addon.Application.StatusBar.SetText("Processo concluído com sucesso..", BoMessageTime.bmt_Medium, BoStatusBarMessageType.smt_Success);
                    this.Freeze(false);
                }
            }

            catch (Exception ex)
            {
                Addon.Application.StatusBar.SetText("Erro: " + ex.Message, BoMessageTime.bmt_Medium, BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                this.Freeze(false);
            }
        }
        public override void SBO_ChooseFromList(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {
            try
            {
                if (pVal.ItemUID == "edPv")
                {
                    this.oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                    if (this.oCFLEvento.BeforeAction == false)
                    {
                        this.oDataTable = this.oCFLEvento.SelectedObjects;
                        if ((this.oDataTable != null))
                            this.DataSources.UserDataSources.Item("udPv").ValueEx = Convert.ToString(oDataTable.GetValue("DocEntry", 0));

                    }
                }
                if (pVal.ItemUID == "edCliente")
                {
                    this.oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                    if (this.oCFLEvento.BeforeAction == false)
                    {
                        this.oDataTable = this.oCFLEvento.SelectedObjects;
                        if ((this.oDataTable != null))
                            this.DataSources.UserDataSources.Item("udCli").ValueEx = Convert.ToString(oDataTable.GetValue("CardCode", 0));
                    }
                }
            }
            catch (Exception ex)
            {
                Addon.Application.StatusBar.SetText("Erro: " + ex.Message, BoMessageTime.bmt_Medium, BoStatusBarMessageType.smt_Error);
            }
        }
        public void BrowserExcel()
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                    ((SAPbouiCOM.EditText)this.Items.Item("excel").Specific).Value = openFileDialog.FileName;

            }
        }
        public void BrowserLog()
        {
            using (FolderBrowserDialog dl = new FolderBrowserDialog())
            {

                if (dl.ShowDialog() == DialogResult.OK)
                    ((SAPbouiCOM.EditText)this.Items.Item("log").Specific).Value = dl.SelectedPath;

            }
        }
        #endregion
        #region EVENTOS NÃO USADOS



        public override void SBO_Click(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_ComboSelect(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_DataSourceLoad(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_DoubleClick(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormActivate(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormClose(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormDataAdd(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormDataDelete(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormDataEvent(ref BusinessObjectInfo BusinessObjectInfo, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormDataLoad(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormDataUpdate(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormDeactivate(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormGotFocus(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormGRidSort(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormKeyDown(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormLoad(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormResize(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_FormVisible(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_KeyDown(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_LostFocus(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {
            if (pVal.ItemUID == "excel" && !pVal.BeforeAction && pVal.CharPressed == 0)
            {
                if (string.IsNullOrEmpty(((SAPbouiCOM.EditText)this.Items.Item("excel").Specific).Value))
                {
                    Thread td = new Thread(new ThreadStart(this.BrowserExcel));
                    td.SetApartmentState(ApartmentState.STA);
                    td.IsBackground = true;
                    td.Start();
                }
            }
            if (pVal.ItemUID == "log" && !pVal.BeforeAction && pVal.CharPressed == 0)
            {
                if (string.IsNullOrEmpty(((SAPbouiCOM.EditText)this.Items.Item("log").Specific).Value))
                {
                    Thread td = new Thread(new ThreadStart(this.BrowserLog));
                    td.SetApartmentState(ApartmentState.STA);
                    td.IsBackground = true;
                    td.Start();
                }
            }
        }

        public override void SBO_MatrixCollapsePressed(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_MatrixLinkPressed(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_MatrixLoad(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_MenuClick(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_MenuEvent(ref MenuEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_RightClick(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }

        public override void SBO_RightClickEvent(ref ContextMenuInfo eventInfo, ref bool BubbleEvent)
        {

        }

        public override void SBO_StatusBarEvent(string Text, BoStatusBarMessageType MessageType)
        {

        }

        public override void SBO_Validate(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {

        }
        #endregion
    }
}
