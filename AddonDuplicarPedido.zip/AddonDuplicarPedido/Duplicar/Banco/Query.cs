﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddonDuplicarPedido.Duplicar.Banco
{
    public abstract class Query
    {
        public static string PedidoVenda()
        {
            return ""+
                "SELECT " +
                "	T1.DOCDATE," +
                "	T1.DOCDUEDATE," +
                "	T1.CARDCODE," +
                "	T1.CARDNAME," +
                "	T1.DISCPRCNT," +
                "	T1.DISCSUM," +
                "	T1.DOCCUR," +
                "	T1.DOCRATE," +
                "	T1.DOCTOTAL," +
                "	T1.DOCTOTALFC," +
                "	T1.PAIDTODATE," +
                "	T1.PAIDFC," +
                "	T1.GROSPROFIT," +
                "	T1.COMMENTS," +
                "	T1.DOCTOTALSY," +
                "	T1.PAIDSYS," +
                "	T1.INDICATOR," +
                "	T1.PROJECT," +
                "	T1.BPLID," +
                "	T1.BPLNAME," +
                "	T1.HEADER," +
                "	T1.FOOTER," +
                "	T1.SEQCODE" +
#if !DEBUG
                "	,T1.U_LG_REEMBOLSO" +
                "	,T1.U_LG_GERADO" +
                "	,T1.U_LG_IMAGEM" +
                "	,T1.U_REIS_OBS_FINAN" +
                "	,T1.U_LG_NMROLOTE" +
                "	,T1.U_LG_DOCNUMOP" +
                "	,T1.U_LG_IMAGEM1" +
                "	,T1.U_LG_IMAGEM2" +
                "	,T1.U_OBSERVACAOSTATUS" +
                "	,T1.U_REIS_PENALIZACAO" +
                "	,T1.U_U_REIS_STATUSNOVO" +
                "	,T1.U_NOSSONUMERO" +
                "	,ISNULL(T1.U_ANTECIPADO,'N') AS U_ANTECIPADO" +
                "" +
#endif
                "	,T2.ITEMCODE" +
                "	,T2.QUANTITY" +
                "	,T2.SHIPDATE" +
                "	,T2.PRICE" +
                "	,T2.DISCPRCNT" +
                "	,T2.LINETOTAL" +
                "	,T2.WHSCODE" +
                "	,T2.SLPCODE" +
                "	,T2.COMMISSION" +
                "	,T2.ACCTCODE" +
                "	,T2.DOCDATE" +
                "	,T2.OCRCODE" +
                "	,T2.PROJECT" +
                "	,T2.TAXCODE" +
                "	,T2.USAGE" +
                "	,T2.OCRCODE2" +
                "	,T2.OCRCODE3" +
                "	,T2.OCRCODE4" +
                "	,T2.OCRCODE5" +
#if !DEBUG
                "	,T2.U_CSTIPI" +
                "	,T2.U_CSTPIS" +
                "	,T2.U_CSTCOFINS" +
                "	,T2.U_LG_CHAVEDESP" +
                "	,T2.U_LG_NMROLOTE" +
                "	,T2.U_LG_NMROPROTOCOLO" +
                "	,T2.U_LG_CHAVETEDESCO" +
                "	,T2.U_TIPO_DOC" +
                "	,T2.U_CEP" +
                "	,T2.U_ENVI_PARA" +
                "	,T2.U_NOME_SOLIC" +
                "	,T2.U_CIDADE" +
                "	,T2.U_POSSUI_AR" +
                "	,T2.U_MEIO_ENVIO" +
                "	,T2.U_OBS" +
                "	,T2.U_REIS_DATAFILTRO" +
                "	,T2.U_U_REIS_MATRICULADM" +
                "	,T2.U_REIS_CUSTODESP" +
                "	,T2.U_REIS_FIXOVARIAVEL" +
                "	,T2.U_REIS_DIRETOINDIRETO" +
                "	,T2.U_REIS_FRETE" +
                "	,T2.U_ALT_PROJECT" +
                "	,T2.U_ALT_OCRCODE" +
                "	,T2.U_ALT_OCRCODE2" +
                "	,T2.U_ALT_OCRCODE3" +
                "	,T2.U_ALT_OCRCODE4" +
                "	,T2.U_ALT_OCRCODE5" +
#endif
                " FROM ORDR T1 " +
                "JOIN RDR1 T2 ON T2.DOCENTRY = T1.DOCENTRY " +
                "WHERE T1.DOCENTRY = '{0}'";
        
        
        }

    }
}
