﻿using System;
using System.Windows.Forms;

namespace AddonDuplicarPedido
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Addon oAddon;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            oAddon = new Addon();
        }
    }
}
