﻿using B1Syswork;
using SAPbouiCOM;
using System;
using System.Windows.Forms;

namespace AddonDuplicarPedido
{
    public class Addon : AddOn
    {
        public Addon()
        {
            try
            {

                this.MenuPath = this.StartupPath + "\\Resources\\XML\\Menu.xml";
                this.Init();
                System.Windows.Forms.Application.Run();

            }
            catch (Exception ex)
            {
                MessageBox.Show(String.Format("Erro ao inciar o AddOn : {0}", ex.Message), this.AddOnName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        protected override void SBO_FormLoad(string FormUID, ref ItemEvent pVal, ref bool BubbleEvent)
        {
           
        }

        protected override void SBO_MenuEvent(ref MenuEvent pVal, ref bool BubbleEvent)
        {
            try
            {
                switch (pVal.MenuUID)
                {
                    case "B1S_DupPV":
                        if (pVal.BeforeAction == false)
                            FormsManager.AddNewForm(new Duplicar.Form());
                        break;


                }
            }
            catch (Exception ex)
            {
                Addon.Application.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        protected override void SetFilters()
        {
          
        }
    }
}
